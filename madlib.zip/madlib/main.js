document.getElementById("btn").addEventListener("click", madLib);

function madLib() {
    // Input
    let name = document.getElementById("friend-name").value;
    let adjective1 = document.getElementById("adj1").value;
    let pln = document.getElementById("plnoun").value;
    let adjective2 = document.getElementById("adj2").value;
    let pastverb = document.getElementById("verb").value;

    // Process
    let result = "Yesterday, " + name + " went shopping and bought some " + adjective1 + " " + pln + ". Unfortunately, they were " + adjective2 + " so they had to be " + pastverb + "."

    // Output
    document.getElementById("result").innerHTML = result
}